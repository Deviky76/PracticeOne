package demojava1;

public class demotest2 {
	
	public static void main(String arg1) throws Throwable
	{
		arg1 ="apple";
		//arg2 ="tomato";
		
		if (arg1 == "apple")
		{
	        System.out.println("apple in Arg1");
	    } 
		else if (arg1 == "tamoto")
	    {
	        System.out.println("tamoto in Arg1");
	    }
	}

}

}
